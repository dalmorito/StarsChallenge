import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { getTournamentBracket } from "@/lib/api";
import type { BracketMatch } from "@shared/schema";
import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Trophy, Heart, Star, ChevronRight, Award } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

// Layout constants for bracket visualization
const MATCH_WIDTH = 240;
const MATCH_HEIGHT = 48;
const HORIZONTAL_GAP = 100;
const VERTICAL_GAP = 24;

interface BracketMatchProps {
  match: BracketMatch;
  x: number;
  y: number;
  isCurrentMatch: boolean;
}

function BracketMatchItem({ match, x, y, isCurrentMatch }: BracketMatchProps) {
  return (
    <motion.div
      className={`absolute rounded-md bg-white shadow-sm overflow-hidden ${
        isCurrentMatch 
          ? "border-2 border-primary" 
          : match.completed 
            ? "border border-gray-200" 
            : "border border-dashed border-gray-300"
      }`}
      style={{
        left: `${x}px`,
        top: `${y}px`,
        width: `${MATCH_WIDTH}px`,
        height: `${MATCH_HEIGHT + 8}px`,
      }}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      whileHover={{ scale: 1.02, boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}
    >
      {isCurrentMatch ? (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="h-full bg-gradient-to-r from-primary to-primary/80 text-white px-3 flex items-center">
                <Star className="h-4 w-4 mr-2 text-yellow-200" />
                <div className="flex-1 truncate font-medium">Current Match</div>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>This is the current active match in progress</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      ) : match.contestant1 && match.contestant2 ? (
        <div className="h-full flex flex-col">
          {/* Contestant 1 */}
          <div 
            className={`flex items-center px-3 py-1 ${
              match.completed && match.winner?.id === match.contestant1.id
                ? "bg-green-50"
                : match.completed
                ? ""
                : ""
            }`}
          >
            <div
              className={`flex-1 truncate text-sm ${
                match.completed && match.winner?.id === match.contestant1.id
                  ? "font-medium text-green-700"
                  : match.completed
                  ? "text-gray-500"
                  : "text-gray-700"
              }`}
            >
              {match.contestant1.name}
            </div>
            
            {match.completed && (
              <Badge 
                variant={match.winner?.id === match.contestant1.id ? "default" : "outline"}
                className={`text-xs h-5 ${match.winner?.id === match.contestant1.id ? "bg-green-600" : "text-gray-400"}`}
              >
                {match.winner?.id === match.contestant1.id ? (
                  <Trophy className="h-3 w-3 mr-1 text-yellow-200" />
                ) : null}
                {match.winner?.id === match.contestant1.id ? "Win" : "Loss"}
              </Badge>
            )}
          </div>
          
          {/* Divider */}
          <div className="h-px bg-gray-200"></div>
          
          {/* Contestant 2 */}
          <div 
            className={`flex items-center px-3 py-1 ${
              match.completed && match.winner?.id === match.contestant2.id
                ? "bg-green-50"
                : match.completed
                ? ""
                : ""
            }`}
          >
            <div
              className={`flex-1 truncate text-sm ${
                match.completed && match.winner?.id === match.contestant2.id
                  ? "font-medium text-green-700"
                  : match.completed
                  ? "text-gray-500"
                  : "text-gray-700"
              }`}
            >
              {match.contestant2.name}
            </div>
            
            {match.completed && (
              <Badge 
                variant={match.winner?.id === match.contestant2.id ? "default" : "outline"}
                className={`text-xs h-5 ${match.winner?.id === match.contestant2.id ? "bg-green-600" : "text-gray-400"}`}
              >
                {match.winner?.id === match.contestant2.id ? (
                  <Trophy className="h-3 w-3 mr-1 text-yellow-200" />
                ) : null}
                {match.winner?.id === match.contestant2.id ? "Win" : "Loss"}
              </Badge>
            )}
          </div>
        </div>
      ) : (
        <div className="h-full flex items-center px-3">
          {match.round === 6 && match.matchNumber === 2 ? (
            <div className="flex items-center">
              <Award className="h-4 w-4 mr-2 text-amber-500" />
              <span className="text-amber-700 font-medium">Bronze Match</span>
            </div>
          ) : match.round === 6 && match.matchNumber === 1 ? (
            <div className="flex items-center">
              <Trophy className="h-4 w-4 mr-2 text-yellow-500" />
              <span className="text-primary font-bold">Final</span>
            </div>
          ) : (
            <span className="text-gray-500 text-sm">
              <ChevronRight className="h-4 w-4 mr-1 inline-block" />
              Round {match.round}
            </span>
          )}
        </div>
      )}
    </motion.div>
  );
}

export default function TournamentBracket() {
  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/tournament/bracket"],
    queryFn: getTournamentBracket,
  });

  const { data: currentMatchData } = useQuery({
    queryKey: ["/api/current-match"],
    queryFn: () => import("@/lib/api").then((api) => api.getCurrentMatch()),
  });

  const bracketRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const updateScale = () => {
      if (bracketRef.current) {
        const containerWidth = bracketRef.current.clientWidth;
        // We need at least 1600px for a good visualization
        const desiredWidth = 1600;
        setScale(Math.min(1, containerWidth / desiredWidth));
      }
    };

    updateScale();
    window.addEventListener("resize", updateScale);
    return () => window.removeEventListener("resize", updateScale);
  }, []);

  if (error) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-medium mb-4">Tournament Bracket</h2>
        <p className="text-error">
          Error loading tournament bracket. Please try refreshing the page.
        </p>
      </div>
    );
  }

  const bracket = data?.data;
  const currentMatchId = currentMatchData?.data?.matchId;

  return (
    <div className="bg-white rounded-lg shadow-md p-6 overflow-x-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold mb-1 bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
            Tournament Bracket
          </h2>
          <p className="text-sm text-muted-foreground flex items-center">
            <ChevronRight className="w-3.5 h-3.5 mr-1" />
            View the full tournament structure and match progression
          </p>
        </div>
        
        {!isLoading && bracket && (
          <Badge variant="outline" className="font-medium">
            <Trophy className="w-3.5 h-3.5 mr-1 text-yellow-500" /> 
            {bracket.rounds.length} Rounds | {bracket.rounds.reduce((acc, round) => acc + round.matches.length, 0)} Matches
          </Badge>
        )}
      </div>
      
      {isLoading ? (
        <Skeleton className="min-w-[1200px] h-[800px]" />
      ) : (
        <div 
          className="min-w-[1200px] h-[800px] relative p-4"
          ref={bracketRef}
          style={{
            transform: `scale(${scale})`,
            transformOrigin: "top left"
          }}
        >
          {bracket?.rounds.map((round, roundIndex) => {
            const roundX = roundIndex * (MATCH_WIDTH + HORIZONTAL_GAP);
            
            // Get the matches for this round
            return round.matches.map((match, matchIndex) => {
              // Calculate vertical position based on round and match number
              let matchesInRound = Math.pow(2, 6 - match.round);
              let baseSpacing = 800 / (matchesInRound + 1);
              let y = matchIndex * baseSpacing * 1.2;
              
              // Special handling for final rounds
              if (match.round === 6) {
                // Final match centered
                if (match.matchNumber === 1) { 
                  y = 300;
                } else {
                  // Bronze match below
                  y = 400;
                }
              }

              // Determine if this is the current match
              const isCurrentMatch = match.id === currentMatchId;
              
              return (
                <BracketMatchItem
                  key={`${match.round}-${match.matchNumber}`}
                  match={match}
                  x={roundX}
                  y={y}
                  isCurrentMatch={isCurrentMatch}
                />
              );
            });
          })}
          
          {/* Draw connector lines here - simplified for now */}
          {/* This would be more complex with SVG path lines */}
        </div>
      )}
    </div>
  );
}
