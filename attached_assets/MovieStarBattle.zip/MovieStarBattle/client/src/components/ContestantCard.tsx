import { useState, useEffect } from "react";
import { Contestant, Match } from "@/lib/types";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { getContestantImages } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Trophy, Heart, Star, Medal, Award, Flame, Sparkles } from "lucide-react";

interface ContestantCardProps {
  contestant: Contestant;
  position: "left" | "right";
  matchId: number;
  isWinner: boolean | null;
  onSelectWinner: (contestantId: number) => void;
  disabled: boolean;
}

export function ContestantCard({
  contestant,
  position,
  matchId,
  isWinner,
  onSelectWinner,
  disabled
}: ContestantCardProps) {
  const [images, setImages] = useState<string[]>([]);
  const [loadingImages, setLoadingImages] = useState(true);
  const { toast } = useToast();

  // Usar a função de API correta para buscar imagens
  const { data, error, isLoading } = useQuery({
    queryKey: [`contestant-images-${contestant.id}`],
    queryFn: () => getContestantImages(contestant.id),
    enabled: !!contestant,
    retry: 1,
    staleTime: 600000, // Cache por 10 minutos
  });
  
  useEffect(() => {
    if (data && data.success) {
      setImages(data.images || []);
      setLoadingImages(false);
    } else if (error) {
      console.error("Erro ao carregar imagens:", error);
      setLoadingImages(false);
      setImages([]);
      toast({
        title: "Erro ao carregar imagens",
        description: "Não foi possível carregar as imagens da concorrente",
        variant: "destructive",
      });
    }
  }, [data, error, toast]);

  // Classes para estilização baseada na posição
  const colorClass = position === "left" ? "primary" : "secondary";
  const borderColorClass = position === "left" ? "border-primary" : "border-secondary";
  const shadowColorClass = position === "left" ? "shadow-primary/30" : "shadow-secondary/30";

  return (
    <motion.div
      initial={{ opacity: 0, y: position === "left" ? -20 : 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card className="bg-white rounded-lg overflow-hidden shadow-lg flex flex-col h-full">
        <div className={`p-4 bg-gradient-to-r ${position === "left" ? "from-primary to-primary/80" : "from-primary/80 to-primary"} text-white`}>
          <div className="flex justify-between items-center mb-2">
            <Badge variant="secondary" className="bg-white/20 hover:bg-white/30">
              <Star className="h-3.5 w-3.5 mr-1 text-yellow-200" />
              Seed #{contestant.id % 64 + 1}
            </Badge>
            
            <Badge variant="secondary" className="bg-white/20 hover:bg-white/30">
              <Sparkles className="h-3.5 w-3.5 mr-1 text-blue-200" />
              {contestant.currentPoints} pts
            </Badge>
          </div>
          
          <h3 className="text-xl font-bold flex items-center">
            <Heart className="w-5 h-5 mr-2 text-red-200" />
            {contestant.name}
          </h3>
          
          <div className="flex gap-2 mt-1">
            {contestant.goldMedals > 0 && (
              <Badge variant="secondary" className="bg-yellow-500/30 text-yellow-100">
                <Trophy className="h-3 w-3 mr-1" />
                {contestant.goldMedals} Gold
              </Badge>
            )}
            {contestant.silverMedals > 0 && (
              <Badge variant="secondary" className="bg-gray-400/30 text-gray-100">
                <Medal className="h-3 w-3 mr-1" />
                {contestant.silverMedals} Silver
              </Badge>
            )}
            {contestant.bronzeMedals > 0 && (
              <Badge variant="secondary" className="bg-amber-700/30 text-amber-100">
                <Award className="h-3 w-3 mr-1" />
                {contestant.bronzeMedals} Bronze
              </Badge>
            )}
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-2 p-3 bg-gray-50">
          {loadingImages || isLoading ? (
            <>
              <div className="w-full rounded-md aspect-[2/3] bg-gray-200 animate-pulse"></div>
              <div className="w-full rounded-md aspect-[2/3] bg-gray-200 animate-pulse"></div>
              <div className="w-full rounded-md aspect-[2/3] bg-gray-200 animate-pulse"></div>
            </>
          ) : images.length > 0 ? (
            images.map((imageUrl, index) => (
              <motion.div
                key={index}
                whileHover={{ scale: 1.05, y: -5 }}
                className="overflow-hidden rounded-md shadow-sm"
              >
                <img 
                  src={imageUrl} 
                  alt={`${contestant.name} image ${index + 1}`} 
                  className="w-full aspect-[2/3] object-cover"
                  onError={(e) => {
                    // Imagem de fallback em caso de erro
                    const placeholderUrl = `https://via.placeholder.com/200x300?text=${encodeURIComponent(contestant.name)}`;
                    e.currentTarget.src = placeholderUrl;
                  }}
                />
              </motion.div>
            ))
          ) : (
            <>
              <div className="w-full rounded-md aspect-[2/3] bg-gray-100 flex items-center justify-center text-gray-400">No image</div>
              <div className="w-full rounded-md aspect-[2/3] bg-gray-100 flex items-center justify-center text-gray-400">No image</div>
              <div className="w-full rounded-md aspect-[2/3] bg-gray-100 flex items-center justify-center text-gray-400">No image</div>
            </>
          )}
        </div>
        
        <div className="p-4 mt-auto border-t bg-white">
          <div className="flex justify-between items-center mb-3">
            <Badge variant="outline" className="gap-1">
              <Flame className="h-3.5 w-3.5 text-green-500" />
              {contestant.wins} Wins
            </Badge>
            
            <span className="text-sm text-gray-500">
              {Math.round((contestant.wins / (contestant.wins + contestant.losses || 1)) * 100)}% Win Rate
            </span>
            
            <Badge variant="outline" className="gap-1">
              <Flame className="h-3.5 w-3.5 text-red-500" />
              {contestant.losses} Losses
            </Badge>
          </div>
          
          <motion.div whileTap={{ scale: 0.97 }}>
            <Button
              onClick={() => onSelectWinner(contestant.id)}
              disabled={disabled}
              className={`w-full py-5 font-bold ${
                isWinner === true 
                  ? 'bg-green-600 hover:bg-green-700 text-white shadow-md shadow-green-600/20' 
                  : position === "left"
                    ? 'bg-primary hover:bg-primary/90 text-white shadow-md shadow-primary/20'
                    : 'bg-primary hover:bg-primary/90 text-white shadow-md shadow-primary/20'
              }`}
            >
              {isWinner === true ? (
                <>
                  <Trophy className="h-4 w-4 mr-2" />
                  Winner Selected!
                </>
              ) : (
                <>
                  <Star className="h-4 w-4 mr-2" />
                  Vote for {contestant.name}
                </>
              )}
            </Button>
          </motion.div>
        </div>
      </Card>
    </motion.div>
  );
}
