import { useQuery } from "@tanstack/react-query";
import CurrentMatch from "./CurrentMatch";
import TournamentBracket from "./TournamentBracket";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { getTournamentProgress } from "@/lib/api";

export default function TournamentView() {
  const { data: progressData, isLoading: progressLoading } = useQuery({
    queryKey: ["/api/tournament-progress"],
    queryFn: getTournamentProgress,
    refetchInterval: 5000, // Refetch every 5 seconds
  });

  const progress = progressData?.data || {
    totalMatches: 63,
    completedMatches: 0,
    currentRound: 1,
    currentMatch: 1,
    roundName: "Round of 64",
    percentComplete: 0,
  };

  return (
    <div id="tournamentView">
      {/* Current Match Section */}
      <CurrentMatch />

      {/* Tournament Progress */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-medium mb-4">Tournament Progress</h2>
        {progressLoading ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <Skeleton className="h-6 w-48" />
              <Skeleton className="h-6 w-64" />
            </div>
            <Skeleton className="h-2 w-full" />
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-4">
              <div className="text-md text-textSecondary">
                {progress.roundName} - Match {progress.currentMatch}
              </div>
              <div className="flex items-center">
                <span className="text-md font-medium mr-2">
                  {progress.completedMatches}
                </span>
                <span className="text-md text-textSecondary mr-2">of</span>
                <span className="text-md font-medium">
                  {progress.totalMatches}
                </span>
                <span className="text-md text-textSecondary ml-2">
                  matches completed
                </span>
              </div>
            </div>
            <Progress value={progress.percentComplete} className="h-2" />
          </>
        )}
      </div>

      {/* Tournament Bracket */}
      <TournamentBracket />
    </div>
  );
}
