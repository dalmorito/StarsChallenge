import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { initializeTournament, advanceToNextMatch } from "@/lib/api";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { Play, RefreshCw, Trophy, AlertTriangle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export default function TournamentControls() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const startNewTournamentMutation = useMutation({
    mutationFn: initializeTournament,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tournament/current"] });
      queryClient.invalidateQueries({ queryKey: ["/api/current-match"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tournament-progress"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tournament/bracket"] });
      
      toast({
        title: "New Tournament Started",
        description: "A new tournament has been initialized with 64 participants.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to start a new tournament. Please try again.",
        variant: "destructive",
      });
    },
  });

  const nextMatchMutation = useMutation({
    mutationFn: advanceToNextMatch,
    onSuccess: (data) => {
      if (data.success) {
        queryClient.invalidateQueries({ queryKey: ["/api/current-match"] });
        queryClient.invalidateQueries({ queryKey: ["/api/tournament-progress"] });
        queryClient.invalidateQueries({ queryKey: ["/api/tournament/bracket"] });
        
        toast({
          title: "Next Match",
          description: "Advanced to the next match.",
        });
      } else {
        toast({
          title: "Notice",
          description: data.message || "No next match available.",
          variant: "default",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to advance to the next match. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleNewTournament = () => {
    startNewTournamentMutation.mutate();
  };

  const handleNextMatch = () => {
    nextMatchMutation.mutate();
  };

  return (
    <motion.div 
      className="flex space-x-4 items-center"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button 
                    variant="secondary" 
                    className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white hover:opacity-90 font-medium"
                    size="lg"
                  >
                    <Trophy className="h-4 w-4 mr-2" />
                    New Tournament
                  </Button>
                </motion.div>
              </AlertDialogTrigger>
              <AlertDialogContent className="border-0 shadow-xl">
                <AlertDialogHeader>
                  <AlertDialogTitle className="text-xl flex items-center text-primary">
                    <Trophy className="h-5 w-5 mr-2" />
                    Start a New Tournament?
                  </AlertDialogTitle>
                  <AlertDialogDescription className="text-base">
                    <div className="flex items-start mb-2 text-amber-500">
                      <AlertTriangle className="h-5 w-5 mr-2 shrink-0 mt-0.5" />
                      <span>This will end the current tournament and all progress will be lost.</span>
                    </div>
                    <p className="mt-2">A new tournament will be initialized with 64 random contestants from the database.</p>
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter className="gap-2">
                  <AlertDialogCancel className="mt-0">Cancel</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={handleNewTournament}
                    className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white hover:opacity-90"
                    disabled={startNewTournamentMutation.isPending}
                  >
                    {startNewTournamentMutation.isPending ? 
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : 
                      <Trophy className="h-4 w-4 mr-2" />
                    }
                    {startNewTournamentMutation.isPending ? "Creating..." : "Start New Tournament"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </TooltipTrigger>
          <TooltipContent>
            <p>Create a new tournament with 64 random contestants</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="default"
                className="bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:opacity-90 font-medium shadow-md"
                onClick={handleNextMatch}
                disabled={nextMatchMutation.isPending}
                size="lg"
              >
                {nextMatchMutation.isPending ? 
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : 
                  <Play className="h-4 w-4 mr-2" />
                }
                {nextMatchMutation.isPending ? "Advancing..." : "Next Match"}
              </Button>
            </motion.div>
          </TooltipTrigger>
          <TooltipContent>
            <p>Skip the current match and advance to the next one</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </motion.div>
  );
}
