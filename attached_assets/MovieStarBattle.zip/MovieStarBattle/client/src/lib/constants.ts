// Constants used in the tournament application

// Round names for tournament bracket
export const ROUND_NAMES = [
  'Round of 64',
  'Round of 32',
  'Round of 16',
  'Quarter Finals',
  'Semi Finals',
  'Finals',
  '3rd Place Match'
];

// Points awarded for tournament positions
export const TOURNAMENT_POINTS = {
  FIRST: 50,   // 1st place
  SECOND: 40,  // 2nd place
  THIRD: 35,   // 3rd place
  FOURTH: 30,  // 4th place
  FIFTH_TO_EIGHTH: 25,  // 5th-8th place
  NINTH_TO_SIXTEENTH: 20,  // 9th-16th place
  SEVENTEENTH_TO_THIRTYSECOND: 15,  // 17th-32nd place
  THIRTYTHIRD_TO_SIXTYFOURTH: 10   // 33rd-64th place
};

// Number of participants in the tournament
export const TOTAL_PARTICIPANTS = 64;

// Colors for charts
export const CHART_COLORS = [
  '#8B5CF6',  // Primary (purple)
  '#EC4899',  // Secondary (pink)
  '#F59E0B',  // Accent (amber)
  '#10B981',  // Success (green)
  '#3B82F6',  // Blue
  '#14B8A6',  // Teal
  '#EF4444',  // Red
  '#A78BFA'   // Light purple
];

// Status colors for tournament progress
export const STATUS_COLORS = {
  COMPLETED: 'text-green-500',
  IN_PROGRESS: 'text-yellow-500',
  PENDING: 'text-gray-400'
};

// Tabs for the main application
export const TABS = [
  { id: 'current-match', label: 'Current Match', icon: 'gamepad' },
  { id: 'tournament-bracket', label: 'Tournament Bracket', icon: 'sitemap' },
  { id: 'leaderboard', label: 'Leaderboard', icon: 'medal' },
  { id: 'ranking', label: 'Point Ranking', icon: 'list-ol' },
  { id: 'statistics', label: 'Statistics', icon: 'chart-bar' }
];

// Default starting points for contestants
export const DEFAULT_POINTS = 1000;

// Points exchange percentage in matches
export const POINTS_EXCHANGE_PERCENTAGE = 0.1;  // 10%
