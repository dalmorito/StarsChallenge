import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema from the template, kept for reference
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Contestant schema
export const contestants = pgTable("contestants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  points: integer("points").notNull().default(1000), // Points for points ranking system (starting at 1000)
  tournamentPoints: integer("tournament_points").notNull().default(0), // Points from tournament placements
  matches: integer("matches").notNull().default(0),
  wins: integer("wins").notNull().default(0),
  losses: integer("losses").notNull().default(0),
  goldMedals: integer("gold_medals").notNull().default(0),
  silverMedals: integer("silver_medals").notNull().default(0),
  bronzeMedals: integer("bronze_medals").notNull().default(0),
  active: boolean("active").notNull().default(true), // Whether the contestant is in the current tournament
});

export const insertContestantSchema = createInsertSchema(contestants).pick({
  name: true,
  points: true,
  tournamentPoints: true,
  matches: true,
  wins: true,
  losses: true,
  goldMedals: true,
  silverMedals: true,
  bronzeMedals: true,
  active: true,
});

export type InsertContestant = z.infer<typeof insertContestantSchema>;
export type Contestant = typeof contestants.$inferSelect;

// Tournament schema
export const tournaments = pgTable("tournaments", {
  id: serial("id").primaryKey(),
  startDate: timestamp("start_date").notNull().defaultNow(),
  endDate: timestamp("end_date"),
  completed: boolean("completed").notNull().default(false),
  currentRound: integer("current_round").notNull().default(0),
  currentMatch: integer("current_match").notNull().default(0),
  matches: integer("matches").notNull().default(0),
  champion: integer("champion"),
  runnerUp: integer("runner_up"),
  thirdPlace: integer("third_place"),
});

export const insertTournamentSchema = createInsertSchema(tournaments).pick({
  startDate: true,
  endDate: true,
  completed: true,
  currentRound: true,
  currentMatch: true,
  matches: true,
  champion: true,
  runnerUp: true,
  thirdPlace: true,
});

export type InsertTournament = z.infer<typeof insertTournamentSchema>;
export type Tournament = typeof tournaments.$inferSelect;

// Match schema
export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  tournamentId: integer("tournament_id").notNull(),
  round: integer("round").notNull(),
  matchNumber: integer("match_number").notNull(),
  contestant1Id: integer("contestant1_id").notNull(),
  contestant2Id: integer("contestant2_id").notNull(),
  winnerId: integer("winner_id"),
  completed: boolean("completed").notNull().default(false),
});

export const insertMatchSchema = createInsertSchema(matches).pick({
  tournamentId: true,
  round: true,
  matchNumber: true,
  contestant1Id: true,
  contestant2Id: true,
  winnerId: true,
  completed: true,
});

export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type Match = typeof matches.$inferSelect;

// PointHistory schema for tracking point changes over time
export const pointHistory = pgTable("point_history", {
  id: serial("id").primaryKey(),
  contestantId: integer("contestant_id").notNull(),
  points: integer("points").notNull(),
  tournamentId: integer("tournament_id").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertPointHistorySchema = createInsertSchema(pointHistory).pick({
  contestantId: true,
  points: true,
  tournamentId: true,
  timestamp: true,
});

export type InsertPointHistory = z.infer<typeof insertPointHistorySchema>;
export type PointHistory = typeof pointHistory.$inferSelect;

// Image cache schema for temporarily storing image URLs
export const imageCache = pgTable("image_cache", {
  id: serial("id").primaryKey(),
  contestantId: integer("contestant_id").notNull(),
  imageUrls: text("image_urls").array().notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertImageCacheSchema = createInsertSchema(imageCache).pick({
  contestantId: true,
  imageUrls: true,
  createdAt: true,
});

export type InsertImageCache = z.infer<typeof insertImageCacheSchema>;
export type ImageCache = typeof imageCache.$inferSelect;

// Constant list of all available contestants
export const CONTESTANTS_LIST = [
  "Elle Lee", "Asa Akira", "Sumire Mizukawa", "Eva Lovia", "London Keyes",
  "Maria Ozawa", "Sharon Lee", "Morgan Lee", "Alina Li", "Jennie Rose",
  "Polly Pons", "Rae Lil Black", "Miko Lee", "Tia Ling", "Kaylani Lei",
  "Kalina Ryu", "Saya Song", "Miko Sinz", "Daisy Summers", "Jasmine Sherni",
  "Alexia Anders", "Ember Snow", "Jayna Oso", "Nautica Thorn", "Jayden Lee",
  "Kendra Spade", "Jade Hsu", "Marica Hase", "Brenna Sparks", "Ariel Rose",
  "Sunny Leone", "Roxy Jezel", "Cindy Starfall", "Jade Kimiko", "May Thai",
  "Lulu Chu", "Tera Patrick", "Julia Kyoka", "Venus Lux", "Mia Khalifa",
  "Jessica Bangkok", "Maxine X", "Avena Lee", "Dana Vespoli", "Katsuni",
  "Kimmy Kimm", "Jasmine Grey", "Evelyn Lin", "Clara Trinity", "Charmane Star",
  "Mia Rider", "Jureka Del Mar", "Tia Tanaka", "Nicole Doshi", "Lily Thai",
  "Vina Skyy", "Lia Lin", "Priya Rai", "Mia Lelani", "Lea Hart",
  "Jade Kush", "Avery Black", "Amai Liu", "Sofia Takigawa", "Linda Lan",
  "Christy White", "Kelsey Kane", "Jodie Taylor", "Tiffany Doll", "Adria Rae",
  "Alexa Flexy", "Sammie Rhodes", "Monika Fox", "Kamryn Jayde", "Chanel Camryn",
  "Adel Asanty", "Zazie Skymm", "Jade Nile", "Rosalyn Sphinx", "Ash Hollywood",
  "Ava Ston", "Sybil A", "Sienna Grace", "Jennifer Dark", "Tracy Rose",
  "Maitland Ward", "Raven Rockette", "Tricia Oaks", "Aliya Brynn", "Romi Rain",
  "Shrooms Q", "Delilah Dagger", "Megan Fiore", "Melanie Hicks", "Lanny Barbie",
  "Gisha Forza", "Zena Little", "Layla Sin", "Roxy Lips", "Missy Stone",
  "Corra Cox", "Jasmine Black", "AJ Applegate", "Sandra Shine", "Kathia Nobili",
  "Dana Wolf", "Kama Oxi", "Milana Ricci", "Gina Gerson", "Vicky Vette",
  "Crissy Moran", "Piper Fawn", "Emelie Crystal", "Lauren Phoenix", "Aleska Diamond",
  "Natalia Starr", "Naomi Blue", "Maya Grand", "Mia Sollis", "Skyler Storm",
  "Bree Olson", "Explicit Kait", "Sandra Romain", "Sasha Foxxx", "Hadley Mason",
  "Vanessa Decker", "Ailee Anne", "Cindy Shine", "Anna Claire Clouds", "Lacy Lennon",
  "Roxy Lip", "Lana Roy", "Valentina Bellucci", "Jayme Langford", "Ella Reese",
  "Jayden Cole", "Janine Lindemulder", "Candice Demellza", "Anny Aurora", "Angelina Diamanti",
  "RayVeness", "Venus Vixen", "Sara Diamante", "Serena Hill", "Aria Kai",
  "Brea Bennett", "Hope Harper", "Kay Carter", "Alli Rae", "Faye Reagan",
  "Lily Lou", "Corinna Blake", "Bree Daniels", "Tera Joy", "Red Fox",
  "Molly Jane", "Reena Sky", "Tara Morgan", "Maddy May", "Madi Meadows"
];

// Tournament point values based on placement
export const TOURNAMENT_POINTS = {
  FIRST: 50,    // 1st place
  SECOND: 40,   // 2nd place
  THIRD: 35,    // 3rd place
  FOURTH: 30,   // 4th place
  FIFTH_EIGHTH: 25, // 5th-8th place (Quarter-finals losers)
  NINTH_SIXTEENTH: 20, // 9th-16th place (Round of 16 losers)
  SEVENTEENTH_THIRTYSECOND: 15, // 17th-32nd place (Round of 32 losers)
  THIRTYTHIRD_SIXTYFOURTH: 10  // 33rd-64th place (Round of 64 losers)
};

// Types for tournament bracket visualization
export type BracketMatch = {
  id: number;
  round: number;
  matchNumber: number;
  contestant1: Contestant | null;
  contestant2: Contestant | null;
  winner: Contestant | null;
  completed: boolean;
};

export type TournamentBracket = {
  rounds: {
    round: number;
    name: string;
    matches: BracketMatch[];
  }[];
};

// Types for current match display
export type CurrentMatchData = {
  matchId: number;
  contestant1: CurrentMatchContestant;
  contestant2: CurrentMatchContestant;
  round: number;
  matchNumber: number;
  roundName: string;
};

export type CurrentMatchContestant = {
  id: number;
  name: string;
  points: number;
  imageUrls: string[];
  rank?: number;
};

// Type for tournament progress
export type TournamentProgress = {
  totalMatches: number;
  completedMatches: number;
  currentRound: number;
  currentMatch: number;
  roundName: string;
  percentComplete: number;
};
