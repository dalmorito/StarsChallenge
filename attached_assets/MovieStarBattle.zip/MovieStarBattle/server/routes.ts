import { Router } from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { ZodError } from "zod";
import { matchesRouter } from "./routes/matches";
import { tournamentRouter } from "./routes/tournament";
import { contestantsRouter } from "./routes/contestants";
import { statsRouter } from "./routes/stats";
import { CONTESTANTS_LIST } from "@shared/schema";
import { fetchContestantImages } from "./image-service";

// Input validation schema for selecting a winner
const selectWinnerSchema = z.object({
  matchId: z.number(),
  winnerId: z.number()
});

// Initialize tournament if needed
async function ensureTournamentExists() {
  const currentTournament = await storage.getCurrentTournament();
  if (!currentTournament) {
    // If no tournament exists, create one
    await storage.initializeNewTournament();
  }
}

// Main API router
function createApiRouter() {
  const router = Router();

  // Register sub-routers
  router.use("/matches", matchesRouter);
  router.use("/tournament", tournamentRouter);
  router.use("/contestants", contestantsRouter);
  router.use("/stats", statsRouter);

  // Initialize or restart tournament
  router.post("/initialize", async (req, res) => {
    try {
      const newTournament = await storage.initializeNewTournament();
      res.json({
        success: true,
        message: "Tournament initialized successfully",
        tournament: newTournament
      });
    } catch (error) {
      console.error("Error initializing tournament:", error);
      res.status(500).json({
        success: false,
        message: "Failed to initialize tournament"
      });
    }
  });

  // Get current match
  router.get("/current-match", async (req, res) => {
    try {
      await ensureTournamentExists();
      
      const currentMatchData = await storage.getCurrentMatchData();
      if (!currentMatchData) {
        return res.status(404).json({
          success: false,
          message: "No current match found"
        });
      }
      
      // Ensure we have images for both contestants
      if (currentMatchData.contestant1.imageUrls.length === 0) {
        const images = await fetchContestantImages(
          currentMatchData.contestant1.id,
          currentMatchData.contestant1.name
        );
        currentMatchData.contestant1.imageUrls = images;
      }
      
      if (currentMatchData.contestant2.imageUrls.length === 0) {
        const images = await fetchContestantImages(
          currentMatchData.contestant2.id,
          currentMatchData.contestant2.name
        );
        currentMatchData.contestant2.imageUrls = images;
      }
      
      res.json({
        success: true,
        data: currentMatchData
      });
    } catch (error) {
      console.error("Error fetching current match:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch current match"
      });
    }
  });

  // Select winner for a match
  router.post("/select-winner", async (req, res) => {
    try {
      const { matchId, winnerId } = selectWinnerSchema.parse(req.body);
      
      await storage.selectTournamentWinner(matchId, winnerId);
      
      const nextMatch = await storage.advanceToNextMatch();
      
      res.json({
        success: true,
        message: "Winner selected successfully",
        nextMatch: nextMatch
      });
    } catch (error) {
      console.error("Error selecting winner:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({
          success: false,
          message: "Invalid input data",
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: "Failed to select winner"
      });
    }
  });

  // Advance to the next match
  router.post("/next-match", async (req, res) => {
    try {
      const nextMatch = await storage.advanceToNextMatch();
      
      if (!nextMatch) {
        return res.status(404).json({
          success: false,
          message: "No next match available, tournament may be completed"
        });
      }
      
      res.json({
        success: true,
        message: "Advanced to next match",
        nextMatch: nextMatch
      });
    } catch (error) {
      console.error("Error advancing to next match:", error);
      res.status(500).json({
        success: false,
        message: "Failed to advance to next match"
      });
    }
  });

  // Get tournament progress
  router.get("/tournament-progress", async (req, res) => {
    try {
      await ensureTournamentExists();
      
      const currentTournament = await storage.getCurrentTournament();
      if (!currentTournament) {
        return res.status(404).json({
          success: false,
          message: "No active tournament found"
        });
      }
      
      const progress = await storage.getTournamentProgress(currentTournament.id);
      
      res.json({
        success: true,
        data: progress
      });
    } catch (error) {
      console.error("Error fetching tournament progress:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch tournament progress"
      });
    }
  });

  // Get contestant information
  router.get("/contestants/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({
          success: false,
          message: "Invalid contestant ID"
        });
      }
      
      const contestant = await storage.getContestantById(id);
      if (!contestant) {
        return res.status(404).json({
          success: false,
          message: "Contestant not found"
        });
      }
      
      // Get point history for the contestant
      const pointHistory = await storage.getPointHistoryByContestant(id, 10);
      
      res.json({
        success: true,
        data: {
          contestant,
          pointHistory
        }
      });
    } catch (error) {
      console.error("Error fetching contestant:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch contestant information"
      });
    }
  });
  
  // Get contestant images
  router.get("/contestants/:id/images", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({
          success: false,
          message: "Invalid contestant ID"
        });
      }
      
      const contestant = await storage.getContestantById(id);
      if (!contestant) {
        return res.status(404).json({
          success: false,
          message: "Contestant not found"
        });
      }
      
      // Forçar a busca de novas imagens para usar a nova implementação do Google
      // Ignoramos o cache temporariamente para testar a nova implementação
      let images: string[] = await fetchContestantImages(id, contestant.name);
      
      res.json({
        success: true,
        images: images
      });
    } catch (error) {
      console.error("Error fetching contestant images:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch contestant images"
      });
    }
  });

  return router;
}

// Match routes
const matchesRouter = Router();

matchesRouter.get("/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid match ID"
      });
    }
    
    const match = await storage.getMatchById(id);
    if (!match) {
      return res.status(404).json({
        success: false,
        message: "Match not found"
      });
    }
    
    // Get contestant details
    const contestant1 = await storage.getContestantById(match.contestant1Id);
    const contestant2 = await storage.getContestantById(match.contestant2Id);
    const winner = match.winnerId ? await storage.getContestantById(match.winnerId) : null;
    
    res.json({
      success: true,
      data: {
        match,
        contestant1,
        contestant2,
        winner
      }
    });
  } catch (error) {
    console.error("Error fetching match:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch match information"
    });
  }
});

// Tournament routes
const tournamentRouter = Router();

tournamentRouter.get("/current", async (req, res) => {
  try {
    await ensureTournamentExists();
    
    const tournament = await storage.getCurrentTournament();
    if (!tournament) {
      return res.status(404).json({
        success: false,
        message: "No active tournament found"
      });
    }
    
    // Get tournament bracket
    const bracket = await storage.getTournamentBracket(tournament.id);
    
    res.json({
      success: true,
      data: {
        tournament,
        bracket
      }
    });
  } catch (error) {
    console.error("Error fetching tournament:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch tournament information"
    });
  }
});

tournamentRouter.get("/bracket", async (req, res) => {
  try {
    await ensureTournamentExists();
    
    const tournament = await storage.getCurrentTournament();
    if (!tournament) {
      return res.status(404).json({
        success: false,
        message: "No active tournament found"
      });
    }
    
    // Get tournament bracket
    const bracket = await storage.getTournamentBracket(tournament.id);
    
    res.json({
      success: true,
      data: bracket
    });
  } catch (error) {
    console.error("Error fetching tournament bracket:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch tournament bracket"
    });
  }
});

tournamentRouter.get("/history", async (req, res) => {
  try {
    const tournaments = await storage.getAllTournaments();
    
    // Enrich tournament data with winners
    const enrichedTournaments = await Promise.all(
      tournaments.map(async (tournament) => {
        let champion = null;
        let runnerUp = null;
        let thirdPlace = null;
        
        if (tournament.champion) {
          champion = await storage.getContestantById(tournament.champion);
        }
        
        if (tournament.runnerUp) {
          runnerUp = await storage.getContestantById(tournament.runnerUp);
        }
        
        if (tournament.thirdPlace) {
          thirdPlace = await storage.getContestantById(tournament.thirdPlace);
        }
        
        return {
          ...tournament,
          champion,
          runnerUp,
          thirdPlace
        };
      })
    );
    
    res.json({
      success: true,
      data: enrichedTournaments
    });
  } catch (error) {
    console.error("Error fetching tournament history:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch tournament history"
    });
  }
});

// Contestants routes
const contestantsRouter = Router();

contestantsRouter.get("/", async (req, res) => {
  try {
    const contestants = await storage.getAllContestants();
    
    res.json({
      success: true,
      data: contestants
    });
  } catch (error) {
    console.error("Error fetching contestants:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch contestants"
    });
  }
});

contestantsRouter.get("/active", async (req, res) => {
  try {
    const contestants = await storage.getActiveContestants();
    
    res.json({
      success: true,
      data: contestants
    });
  } catch (error) {
    console.error("Error fetching active contestants:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch active contestants"
    });
  }
});

contestantsRouter.get("/ranking", async (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
    
    const contestants = await storage.getTopContestantsByPoints(limit);
    
    res.json({
      success: true,
      data: contestants
    });
  } catch (error) {
    console.error("Error fetching contestant ranking:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch contestant ranking"
    });
  }
});

contestantsRouter.get("/tournament-ranking", async (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
    
    const contestants = await storage.getTopContestantsByTournamentPoints(limit);
    
    res.json({
      success: true,
      data: contestants
    });
  } catch (error) {
    console.error("Error fetching tournament ranking:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch tournament ranking"
    });
  }
});

// Stats routes
const statsRouter = Router();

statsRouter.get("/general", async (req, res) => {
  try {
    const contestants = await storage.getAllContestants();
    
    // Sort by wins and then points
    const sortedContestants = contestants.sort((a, b) => {
      if (a.wins !== b.wins) {
        return b.wins - a.wins;
      }
      return b.points - a.points;
    });
    
    res.json({
      success: true,
      data: sortedContestants
    });
  } catch (error) {
    console.error("Error fetching general stats:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch general stats"
    });
  }
});

statsRouter.get("/top-performers-history", async (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 8;
    
    // Get top performers by points
    const topPerformers = await storage.getTopContestantsByPoints(limit);
    
    // Get their point history
    const contestantIds = topPerformers.map(c => c.id);
    const pointHistory = await storage.getTopContestantsPointHistory(contestantIds);
    
    res.json({
      success: true,
      data: {
        topPerformers,
        pointHistory
      }
    });
  } catch (error) {
    console.error("Error fetching top performers history:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch top performers history"
    });
  }
});

// Esta função será exportada e usada no index.ts
export function setupImageProxy(app: Express) {
  // Proxy de imagens para contornar CORS
  app.get("/proxy-image", async (req: Request, res: Response) => {
    try {
      const imageUrl = req.query.url as string;
      
      if (!imageUrl) {
        return res.status(400).json({ 
          success: false,
          message: "URL de imagem não fornecida"
        });
      }
      
      console.log(`Proxy de imagem: ${imageUrl}`);
  
      const response = await fetch(imageUrl);
      
      if (!response.ok) {
        return res.status(response.status).send("Falha ao buscar imagem");
      }
      
      // Obtém o tipo de conteúdo
      const contentType = response.headers.get("content-type");
      if (contentType) {
        res.setHeader("Content-Type", contentType);
      }
      
      // Configura o cache
      res.setHeader("Cache-Control", "public, max-age=86400"); // Cache por 24 horas
      
      // Transmite a imagem
      const buffer = await response.arrayBuffer();
      res.send(Buffer.from(buffer));
    } catch (error) {
      console.error("Erro no proxy de imagem:", error);
      res.status(500).send("Erro ao processar imagem");
    }
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // API routes
  app.use("/api", createApiRouter());
  
  // Initialize the first tournament if none exists
  await ensureTournamentExists();

  return httpServer;
}
