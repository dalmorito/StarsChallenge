import { 
  Contestant, InsertContestant, 
  Tournament, InsertTournament,
  Match, InsertMatch,
  PointHistory, InsertPointHistory,
  ImageCache, InsertImageCache,
  CONTESTANTS_LIST, TOURNAMENT_POINTS, 
  TournamentBracket, BracketMatch,
  CurrentMatchData, TournamentProgress,
  CurrentMatchContestant
} from "@shared/schema";
import { users, type User, type InsertUser } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // User methods (from template)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Contestant methods
  getAllContestants(): Promise<Contestant[]>;
  getActiveContestants(): Promise<Contestant[]>;
  getContestantById(id: number): Promise<Contestant | undefined>;
  createContestant(contestant: InsertContestant): Promise<Contestant>;
  updateContestant(id: number, contestant: Partial<Contestant>): Promise<Contestant>;
  getTopContestantsByPoints(limit: number): Promise<Contestant[]>;
  getTopContestantsByTournamentPoints(limit: number): Promise<Contestant[]>;
  
  // Tournament methods
  getCurrentTournament(): Promise<Tournament | undefined>;
  getTournamentById(id: number): Promise<Tournament | undefined>;
  getAllTournaments(): Promise<Tournament[]>;
  createTournament(tournament: InsertTournament): Promise<Tournament>;
  updateTournament(id: number, tournament: Partial<Tournament>): Promise<Tournament>;
  
  // Match methods
  getMatchById(id: number): Promise<Match | undefined>;
  getMatchesByTournament(tournamentId: number): Promise<Match[]>;
  getMatchesByRound(tournamentId: number, round: number): Promise<Match[]>;
  createMatch(match: InsertMatch): Promise<Match>;
  updateMatch(id: number, match: Partial<Match>): Promise<Match>;
  getCurrentMatch(): Promise<Match | undefined>;
  
  // Point history methods
  getPointHistoryByContestant(contestantId: number, limit?: number): Promise<PointHistory[]>;
  createPointHistory(pointHistory: InsertPointHistory): Promise<PointHistory>;
  getTopContestantsPointHistory(contestantIds: number[], limit?: number): Promise<Record<number, PointHistory[]>>;
  
  // Image cache methods
  getImageCache(contestantId: number): Promise<ImageCache | undefined>;
  createImageCache(imageCache: InsertImageCache): Promise<ImageCache>;
  
  // Tournament initialization and management
  initializeNewTournament(): Promise<Tournament>;
  selectTournamentWinner(matchId: number, winnerId: number): Promise<void>;
  advanceToNextMatch(): Promise<Match | undefined>;
  
  // Tournament data retrieval
  getTournamentBracket(tournamentId: number): Promise<TournamentBracket>;
  getCurrentMatchData(): Promise<CurrentMatchData | undefined>;
  getTournamentProgress(tournamentId: number): Promise<TournamentProgress>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contestants: Map<number, Contestant>;
  private tournaments: Map<number, Tournament>;
  private matches: Map<number, Match>;
  private pointHistory: PointHistory[];
  private imageCache: Map<number, ImageCache>;
  
  private userCurrentId: number;
  private contestantCurrentId: number;
  private tournamentCurrentId: number;
  private matchCurrentId: number;
  private pointHistoryCurrentId: number;
  private imageCacheCurrentId: number;

  constructor() {
    this.users = new Map();
    this.contestants = new Map();
    this.tournaments = new Map();
    this.matches = new Map();
    this.pointHistory = [];
    this.imageCache = new Map();
    
    this.userCurrentId = 1;
    this.contestantCurrentId = 1;
    this.tournamentCurrentId = 1;
    this.matchCurrentId = 1;
    this.pointHistoryCurrentId = 1;
    this.imageCacheCurrentId = 1;
    
    // Initialize contestants from the list
    this.initializeContestants();
  }

  private initializeContestants() {
    // Create contestants based on the provided list
    CONTESTANTS_LIST.forEach(name => {
      const contestant: InsertContestant = {
        name,
        points: 1000, // Everyone starts with 1000 points
        tournamentPoints: 0,
        matches: 0,
        wins: 0,
        losses: 0,
        goldMedals: 0,
        silverMedals: 0,
        bronzeMedals: 0,
        active: false // Initially no one is active in a tournament
      };
      this.createContestant(contestant);
    });
  }

  // User methods (from template)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Contestant methods
  async getAllContestants(): Promise<Contestant[]> {
    return Array.from(this.contestants.values());
  }

  async getActiveContestants(): Promise<Contestant[]> {
    return Array.from(this.contestants.values()).filter(
      contestant => contestant.active
    );
  }

  async getContestantById(id: number): Promise<Contestant | undefined> {
    return this.contestants.get(id);
  }

  async createContestant(insertContestant: InsertContestant): Promise<Contestant> {
    const id = this.contestantCurrentId++;
    const contestant: Contestant = { ...insertContestant, id };
    this.contestants.set(id, contestant);
    return contestant;
  }

  async updateContestant(id: number, contestantUpdate: Partial<Contestant>): Promise<Contestant> {
    const contestant = this.contestants.get(id);
    if (!contestant) {
      throw new Error(`Contestant with id ${id} not found`);
    }
    
    const updatedContestant = { ...contestant, ...contestantUpdate };
    this.contestants.set(id, updatedContestant);
    return updatedContestant;
  }

  async getTopContestantsByPoints(limit: number): Promise<Contestant[]> {
    return Array.from(this.contestants.values())
      .sort((a, b) => b.points - a.points)
      .slice(0, limit);
  }

  async getTopContestantsByTournamentPoints(limit: number): Promise<Contestant[]> {
    return Array.from(this.contestants.values())
      .sort((a, b) => b.tournamentPoints - a.tournamentPoints)
      .slice(0, limit);
  }

  // Tournament methods
  async getCurrentTournament(): Promise<Tournament | undefined> {
    // Get the most recent tournament that's not completed
    return Array.from(this.tournaments.values())
      .filter(tournament => !tournament.completed)
      .sort((a, b) => b.id - a.id)[0];
  }

  async getTournamentById(id: number): Promise<Tournament | undefined> {
    return this.tournaments.get(id);
  }

  async getAllTournaments(): Promise<Tournament[]> {
    return Array.from(this.tournaments.values())
      .sort((a, b) => b.id - a.id); // Sort by id descending (newest first)
  }

  async createTournament(insertTournament: InsertTournament): Promise<Tournament> {
    const id = this.tournamentCurrentId++;
    const tournament: Tournament = { ...insertTournament, id };
    this.tournaments.set(id, tournament);
    return tournament;
  }

  async updateTournament(id: number, tournamentUpdate: Partial<Tournament>): Promise<Tournament> {
    const tournament = this.tournaments.get(id);
    if (!tournament) {
      throw new Error(`Tournament with id ${id} not found`);
    }
    
    const updatedTournament = { ...tournament, ...tournamentUpdate };
    this.tournaments.set(id, updatedTournament);
    return updatedTournament;
  }

  // Match methods
  async getMatchById(id: number): Promise<Match | undefined> {
    return this.matches.get(id);
  }

  async getMatchesByTournament(tournamentId: number): Promise<Match[]> {
    return Array.from(this.matches.values())
      .filter(match => match.tournamentId === tournamentId)
      .sort((a, b) => {
        // Sort by round first, then by match number
        if (a.round !== b.round) {
          return a.round - b.round;
        }
        return a.matchNumber - b.matchNumber;
      });
  }

  async getMatchesByRound(tournamentId: number, round: number): Promise<Match[]> {
    return Array.from(this.matches.values())
      .filter(match => match.tournamentId === tournamentId && match.round === round)
      .sort((a, b) => a.matchNumber - b.matchNumber);
  }

  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const id = this.matchCurrentId++;
    const match: Match = { ...insertMatch, id };
    this.matches.set(id, match);
    return match;
  }

  async updateMatch(id: number, matchUpdate: Partial<Match>): Promise<Match> {
    const match = this.matches.get(id);
    if (!match) {
      throw new Error(`Match with id ${id} not found`);
    }
    
    const updatedMatch = { ...match, ...matchUpdate };
    this.matches.set(id, updatedMatch);
    return updatedMatch;
  }

  async getCurrentMatch(): Promise<Match | undefined> {
    const tournament = await this.getCurrentTournament();
    if (!tournament) return undefined;
    
    // Find the current match based on tournament's current round and match
    return Array.from(this.matches.values()).find(
      match => match.tournamentId === tournament.id && 
               match.round === tournament.currentRound && 
               match.matchNumber === tournament.currentMatch &&
               !match.completed
    );
  }

  // Point history methods
  async getPointHistoryByContestant(contestantId: number, limit?: number): Promise<PointHistory[]> {
    const history = this.pointHistory
      .filter(entry => entry.contestantId === contestantId)
      .sort((a, b) => {
        // Sort by timestamp descending (newest first)
        const dateA = new Date(a.timestamp).getTime();
        const dateB = new Date(b.timestamp).getTime();
        return dateB - dateA;
      });
    
    return limit ? history.slice(0, limit) : history;
  }

  async createPointHistory(insertPointHistory: InsertPointHistory): Promise<PointHistory> {
    const id = this.pointHistoryCurrentId++;
    const pointHistory: PointHistory = { ...insertPointHistory, id };
    this.pointHistory.push(pointHistory);
    return pointHistory;
  }

  async getTopContestantsPointHistory(contestantIds: number[], limit?: number): Promise<Record<number, PointHistory[]>> {
    const result: Record<number, PointHistory[]> = {};
    
    for (const contestantId of contestantIds) {
      result[contestantId] = await this.getPointHistoryByContestant(contestantId, limit);
    }
    
    return result;
  }

  // Image cache methods
  async getImageCache(contestantId: number): Promise<ImageCache | undefined> {
    // Retornamos undefined para forçar a busca de novas imagens
    // com os novos parâmetros de segurança da API
    return undefined;
  }

  async createImageCache(insertImageCache: InsertImageCache): Promise<ImageCache> {
    const id = this.imageCacheCurrentId++;
    const imageCache: ImageCache = { ...insertImageCache, id };
    this.imageCache.set(insertImageCache.contestantId, imageCache);
    return imageCache;
  }

  // Tournament initialization and management
  async initializeNewTournament(): Promise<Tournament> {
    // First, check if there's an active tournament
    const currentTournament = await this.getCurrentTournament();
    if (currentTournament) {
      // Mark the current tournament as completed
      await this.updateTournament(currentTournament.id, { 
        completed: true,
        endDate: new Date()
      });
    }
    
    // Get all contestants
    const allContestants = await this.getAllContestants();
    
    // Get IDs of contestants who were active in the last tournament (if any)
    let previousActiveIds: number[] = [];
    if (currentTournament) {
      const activeContestants = allContestants.filter(c => c.active);
      previousActiveIds = activeContestants.map(c => c.id);
      
      // Reset active flag for all contestants
      for (const contestant of activeContestants) {
        await this.updateContestant(contestant.id, { active: false });
      }
    }
    
    // Select 64 contestants
    // First, find contestants who were eliminated in the first round of the previous tournament
    let eliminatedFirstRound: number[] = [];
    if (currentTournament) {
      const firstRoundMatches = await this.getMatchesByRound(currentTournament.id, 1);
      eliminatedFirstRound = firstRoundMatches
        .filter(match => match.completed && match.winnerId)
        .map(match => {
          // Return the ID of the loser
          if (match.contestant1Id === match.winnerId) {
            return match.contestant2Id;
          } else {
            return match.contestant1Id;
          }
        });
    }
    
    // Get contestants who weren't in the previous tournament
    const inactiveContestants = allContestants.filter(c => !previousActiveIds.includes(c.id));
    
    // Replace the first round losers with new contestants if available
    const newActiveIds: number[] = [];
    
    // First, add contestants who weren't eliminated in the first round of the previous tournament
    if (previousActiveIds.length > 0) {
      const nonEliminatedIds = previousActiveIds.filter(id => !eliminatedFirstRound.includes(id));
      newActiveIds.push(...nonEliminatedIds);
    }
    
    // Then, fill remaining slots from inactive contestants
    const remainingSlots = 64 - newActiveIds.length;
    const randomInactive = this.getRandomElements(inactiveContestants, remainingSlots);
    newActiveIds.push(...randomInactive.map(c => c.id));
    
    // If we still don't have 64, add some from the eliminated ones
    if (newActiveIds.length < 64) {
      const neededFromEliminated = 64 - newActiveIds.length;
      const eliminatedContestants = allContestants.filter(c => eliminatedFirstRound.includes(c.id));
      const randomEliminated = this.getRandomElements(eliminatedContestants, neededFromEliminated);
      newActiveIds.push(...randomEliminated.map(c => c.id));
    }
    
    // Activate the selected contestants
    for (const id of newActiveIds) {
      await this.updateContestant(id, { active: true });
    }
    
    // Create a new tournament
    const newTournament = await this.createTournament({
      startDate: new Date(),
      endDate: undefined,
      completed: false,
      currentRound: 1, // Start with round 1
      currentMatch: 1, // Start with match 1
      matches: 0,
      champion: undefined,
      runnerUp: undefined,
      thirdPlace: undefined
    });
    
    // Create matches for round 1 (32 matches)
    const activeContestants = await this.getActiveContestants();
    const shuffledContestants = this.shuffleArray([...activeContestants]);
    
    for (let i = 0; i < 32; i++) {
      const contestant1 = shuffledContestants[i * 2];
      const contestant2 = shuffledContestants[i * 2 + 1];
      
      await this.createMatch({
        tournamentId: newTournament.id,
        round: 1,
        matchNumber: i + 1,
        contestant1Id: contestant1.id,
        contestant2Id: contestant2.id,
        winnerId: undefined,
        completed: false
      });
    }
    
    return newTournament;
  }

  async selectTournamentWinner(matchId: number, winnerId: number): Promise<void> {
    const match = await this.getMatchById(matchId);
    if (!match) {
      throw new Error(`Match with id ${matchId} not found`);
    }
    
    const tournament = await this.getTournamentById(match.tournamentId);
    if (!tournament) {
      throw new Error(`Tournament not found for match ${matchId}`);
    }
    
    // Get the contestants
    const winner = await this.getContestantById(winnerId);
    const loserId = match.contestant1Id === winnerId ? match.contestant2Id : match.contestant1Id;
    const loser = await this.getContestantById(loserId);
    
    if (!winner || !loser) {
      throw new Error(`Contestant not found`);
    }
    
    // Update the match
    await this.updateMatch(matchId, {
      winnerId,
      completed: true
    });
    
    // Update tournament matches completed count
    await this.updateTournament(tournament.id, {
      matches: tournament.matches + 1
    });
    
    // Update contestant stats
    await this.updateContestant(winner.id, {
      matches: winner.matches + 1,
      wins: winner.wins + 1
    });
    
    await this.updateContestant(loser.id, {
      matches: loser.matches + 1,
      losses: loser.losses + 1
    });
    
    // Update points based on the ranking system
    // Winner gets 10% of loser's points, loser loses 10% of winner's points
    const winnerPointsGain = Math.floor(loser.points * 0.1);
    const loserPointsLoss = Math.floor(winner.points * 0.1);
    
    const updatedWinner = await this.updateContestant(winner.id, {
      points: winner.points + winnerPointsGain
    });
    
    const updatedLoser = await this.updateContestant(loser.id, {
      points: Math.max(1, loser.points - loserPointsLoss) // Ensure points don't go below 1
    });
    
    // Record point history
    await this.createPointHistory({
      contestantId: winner.id,
      points: updatedWinner.points,
      tournamentId: tournament.id,
      timestamp: new Date()
    });
    
    await this.createPointHistory({
      contestantId: loser.id,
      points: updatedLoser.points,
      tournamentId: tournament.id,
      timestamp: new Date()
    });
    
    // Create next round matches if necessary
    if (match.round < 6) { // We have 6 rounds total (64 → 32 → 16 → 8 → 4 → 2 → 1)
      const roundMatches = await this.getMatchesByRound(tournament.id, match.round);
      const completedMatches = roundMatches.filter(m => m.completed);
      
      // If all matches in this round are completed, create matches for the next round
      if (completedMatches.length === roundMatches.length) {
        if (match.round === 5) {
          // If we're in the semi-finals (round 5), create bronze match and final
          const semiFinals = await this.getMatchesByRound(tournament.id, 5);
          
          // Get the two losers for bronze match
          const loser1 = semiFinals[0].contestant1Id === semiFinals[0].winnerId 
            ? semiFinals[0].contestant2Id 
            : semiFinals[0].contestant1Id;
          
          const loser2 = semiFinals[1].contestant1Id === semiFinals[1].winnerId 
            ? semiFinals[1].contestant2Id 
            : semiFinals[1].contestant1Id;
          
          // Create bronze match (3rd place match)
          await this.createMatch({
            tournamentId: tournament.id,
            round: 6,
            matchNumber: 2, // Match #2 is the bronze match
            contestant1Id: loser1,
            contestant2Id: loser2,
            winnerId: undefined,
            completed: false
          });
          
          // Create final match
          await this.createMatch({
            tournamentId: tournament.id,
            round: 6,
            matchNumber: 1, // Match #1 is the final
            contestant1Id: semiFinals[0].winnerId!,
            contestant2Id: semiFinals[1].winnerId!,
            winnerId: undefined,
            completed: false
          });
          
          // Update tournament round and match
          await this.updateTournament(tournament.id, {
            currentRound: 6,
            currentMatch: 1 // Start with the final
          });
        } else if (match.round === 6 && match.matchNumber === 2) {
          // If we just completed the bronze match, the next match is the final
          await this.updateTournament(tournament.id, {
            currentMatch: 1 // Move to the final
          });
          
          // Update the 3rd place contestant
          await this.updateTournament(tournament.id, {
            thirdPlace: winnerId
          });
          
          // Give bronze medal
          await this.updateContestant(winnerId, {
            bronzeMedals: winner.bronzeMedals + 1,
            tournamentPoints: winner.tournamentPoints + TOURNAMENT_POINTS.THIRD
          });
          
          // 4th place gets points too
          await this.updateContestant(loserId, {
            tournamentPoints: loser.tournamentPoints + TOURNAMENT_POINTS.FOURTH
          });
        } else if (match.round === 6 && match.matchNumber === 1) {
          // Tournament is complete, update the winner and runner-up
          await this.updateTournament(tournament.id, {
            completed: true,
            endDate: new Date(),
            champion: winnerId,
            runnerUp: loserId
          });
          
          // Give medals and tournament points
          await this.updateContestant(winnerId, {
            goldMedals: winner.goldMedals + 1,
            tournamentPoints: winner.tournamentPoints + TOURNAMENT_POINTS.FIRST
          });
          
          await this.updateContestant(loserId, {
            silverMedals: loser.silverMedals + 1,
            tournamentPoints: loser.tournamentPoints + TOURNAMENT_POINTS.SECOND
          });
          
          // Assign tournament points to all participants based on their finish
          await this.assignTournamentPoints(tournament.id);
        } else {
          // Create matches for the next round
          const nextRound = match.round + 1;
          const matchesInRound = Math.pow(2, 6 - nextRound);
          
          // For each pair of matches in the current round, create one match in the next round
          for (let i = 0; i < matchesInRound; i++) {
            const match1 = roundMatches[i * 2];
            const match2 = roundMatches[i * 2 + 1];
            
            await this.createMatch({
              tournamentId: tournament.id,
              round: nextRound,
              matchNumber: i + 1,
              contestant1Id: match1.winnerId!,
              contestant2Id: match2.winnerId!,
              winnerId: undefined,
              completed: false
            });
          }
          
          // Update tournament round and match
          await this.updateTournament(tournament.id, {
            currentRound: nextRound,
            currentMatch: 1
          });
        }
      } else {
        // Move to the next match in the current round
        const nextMatchNumber = match.matchNumber + 1;
        const nextMatchExists = roundMatches.some(m => m.matchNumber === nextMatchNumber);
        
        if (nextMatchExists) {
          await this.updateTournament(tournament.id, {
            currentMatch: nextMatchNumber
          });
        }
      }
    }
  }

  async advanceToNextMatch(): Promise<Match | undefined> {
    const tournament = await this.getCurrentTournament();
    if (!tournament) return undefined;
    
    const currentMatch = await this.getCurrentMatch();
    if (!currentMatch) return undefined;
    
    // If the current match is not completed, return it
    if (!currentMatch.completed) {
      return currentMatch;
    }
    
    // If we're in the final match and it's completed, tournament is over
    if (tournament.currentRound === 6 && tournament.currentMatch === 1 && currentMatch.completed) {
      return undefined;
    }
    
    // Get matches in the current round
    const roundMatches = await this.getMatchesByRound(tournament.id, tournament.currentRound);
    
    // If there are more matches in this round, advance to the next one
    if (tournament.currentMatch < roundMatches.length) {
      const nextMatchNumber = tournament.currentMatch + 1;
      await this.updateTournament(tournament.id, {
        currentMatch: nextMatchNumber
      });
      
      return this.getCurrentMatch();
    }
    
    // If we're at the end of the round, check if the next round is set up
    const nextRound = tournament.currentRound + 1;
    const nextRoundMatches = await this.getMatchesByRound(tournament.id, nextRound);
    
    if (nextRoundMatches.length > 0) {
      // Move to the first match of the next round
      await this.updateTournament(tournament.id, {
        currentRound: nextRound,
        currentMatch: 1
      });
      
      return this.getCurrentMatch();
    }
    
    // If we're here, we're waiting for matches to be created for the next round
    return undefined;
  }

  // Tournament data retrieval
  async getTournamentBracket(tournamentId: number): Promise<TournamentBracket> {
    const tournament = await this.getTournamentById(tournamentId);
    if (!tournament) {
      throw new Error(`Tournament with id ${tournamentId} not found`);
    }
    
    const tournamentMatches = await this.getMatchesByTournament(tournamentId);
    const bracket: TournamentBracket = {
      rounds: []
    };
    
    // Round names
    const roundNames = [
      "Round of 64",
      "Round of 32",
      "Round of 16",
      "Quarter-finals",
      "Semi-finals",
      "Finals"
    ];
    
    // Process each round
    for (let round = 1; round <= 6; round++) {
      const matchesInRound = tournamentMatches.filter(match => match.round === round);
      
      // Special handling for final round which has bronze match and final
      if (round === 6) {
        const bronzeMatch = matchesInRound.find(match => match.matchNumber === 2);
        const finalMatch = matchesInRound.find(match => match.matchNumber === 1);
        
        const roundMatches: BracketMatch[] = [];
        
        if (finalMatch) {
          const contestant1 = await this.getContestantById(finalMatch.contestant1Id);
          const contestant2 = await this.getContestantById(finalMatch.contestant2Id);
          const winner = finalMatch.winnerId ? await this.getContestantById(finalMatch.winnerId) : null;
          
          roundMatches.push({
            id: finalMatch.id,
            round: finalMatch.round,
            matchNumber: finalMatch.matchNumber,
            contestant1: contestant1 || null,
            contestant2: contestant2 || null,
            winner: winner,
            completed: finalMatch.completed
          });
        }
        
        if (bronzeMatch) {
          const contestant1 = await this.getContestantById(bronzeMatch.contestant1Id);
          const contestant2 = await this.getContestantById(bronzeMatch.contestant2Id);
          const winner = bronzeMatch.winnerId ? await this.getContestantById(bronzeMatch.winnerId) : null;
          
          roundMatches.push({
            id: bronzeMatch.id,
            round: bronzeMatch.round,
            matchNumber: bronzeMatch.matchNumber,
            contestant1: contestant1 || null,
            contestant2: contestant2 || null,
            winner: winner,
            completed: bronzeMatch.completed
          });
        }
        
        bracket.rounds.push({
          round,
          name: roundNames[round - 1],
          matches: roundMatches
        });
      } else {
        // For other rounds, process normally
        const roundMatches: BracketMatch[] = [];
        
        for (const match of matchesInRound) {
          const contestant1 = await this.getContestantById(match.contestant1Id);
          const contestant2 = await this.getContestantById(match.contestant2Id);
          const winner = match.winnerId ? await this.getContestantById(match.winnerId) : null;
          
          roundMatches.push({
            id: match.id,
            round: match.round,
            matchNumber: match.matchNumber,
            contestant1: contestant1 || null,
            contestant2: contestant2 || null,
            winner: winner,
            completed: match.completed
          });
        }
        
        bracket.rounds.push({
          round,
          name: roundNames[round - 1],
          matches: roundMatches
        });
      }
    }
    
    return bracket;
  }

  async getCurrentMatchData(): Promise<CurrentMatchData | undefined> {
    const currentMatch = await this.getCurrentMatch();
    if (!currentMatch) return undefined;
    
    const tournament = await this.getCurrentTournament();
    if (!tournament) return undefined;
    
    const contestant1 = await this.getContestantById(currentMatch.contestant1Id);
    const contestant2 = await this.getContestantById(currentMatch.contestant2Id);
    
    if (!contestant1 || !contestant2) return undefined;
    
    // Get image cache for contestants
    const imageCache1 = await this.getImageCache(contestant1.id);
    const imageCache2 = await this.getImageCache(contestant2.id);
    
    // Get top contestants by points to determine rank
    const topContestants = await this.getTopContestantsByPoints(100);
    const contestant1Rank = topContestants.findIndex(c => c.id === contestant1.id) + 1;
    const contestant2Rank = topContestants.findIndex(c => c.id === contestant2.id) + 1;
    
    // Round names
    const roundNames = [
      "Round of 64",
      "Round of 32",
      "Round of 16",
      "Quarter-finals",
      "Semi-finals",
      "Finals"
    ];
    
    // Special handling for the final round
    let roundName = roundNames[currentMatch.round - 1];
    if (currentMatch.round === 6 && currentMatch.matchNumber === 2) {
      roundName = "Bronze Match";
    }
    
    return {
      matchId: currentMatch.id,
      contestant1: {
        id: contestant1.id,
        name: contestant1.name,
        points: contestant1.points,
        imageUrls: imageCache1 ? imageCache1.imageUrls : [],
        rank: contestant1Rank
      },
      contestant2: {
        id: contestant2.id,
        name: contestant2.name,
        points: contestant2.points,
        imageUrls: imageCache2 ? imageCache2.imageUrls : [],
        rank: contestant2Rank
      },
      round: currentMatch.round,
      matchNumber: currentMatch.matchNumber,
      roundName
    };
  }

  async getTournamentProgress(tournamentId: number): Promise<TournamentProgress> {
    const tournament = await this.getTournamentById(tournamentId);
    if (!tournament) {
      throw new Error(`Tournament with id ${tournamentId} not found`);
    }
    
    // Total matches in a tournament with 64 participants: 32 + 16 + 8 + 4 + 2 + 1 = 63
    const totalMatches = 63;
    
    // Round names
    const roundNames = [
      "Round of 64",
      "Round of 32",
      "Round of 16",
      "Quarter-finals",
      "Semi-finals",
      "Finals"
    ];
    
    // Special handling for the final round
    let roundName = roundNames[tournament.currentRound - 1];
    const currentMatch = await this.getCurrentMatch();
    if (currentMatch && currentMatch.round === 6 && currentMatch.matchNumber === 2) {
      roundName = "Bronze Match";
    }
    
    // Calculate matches in the current round
    const matchesInRound = Math.pow(2, 6 - tournament.currentRound);
    
    return {
      totalMatches,
      completedMatches: tournament.matches,
      currentRound: tournament.currentRound,
      currentMatch: tournament.currentMatch,
      roundName,
      percentComplete: Math.floor((tournament.matches / totalMatches) * 100)
    };
  }

  // Helper functions
  private assignTournamentPoints(tournamentId: number): Promise<void> {
    return new Promise<void>(async (resolve) => {
      const tournament = await this.getTournamentById(tournamentId);
      if (!tournament) {
        throw new Error(`Tournament with id ${tournamentId} not found`);
      }
      
      const allMatches = await this.getMatchesByTournament(tournamentId);
      
      // Assign points to 5th-8th (Quarter-finals losers)
      const quarterFinals = allMatches.filter(match => match.round === 4);
      for (const match of quarterFinals) {
        const loserId = match.contestant1Id === match.winnerId 
          ? match.contestant2Id 
          : match.contestant1Id;
        
        const loser = await this.getContestantById(loserId);
        if (loser) {
          await this.updateContestant(loser.id, {
            tournamentPoints: loser.tournamentPoints + TOURNAMENT_POINTS.FIFTH_EIGHTH
          });
        }
      }
      
      // Assign points to 9th-16th (Round of 16 losers)
      const roundOf16 = allMatches.filter(match => match.round === 3);
      for (const match of roundOf16) {
        const loserId = match.contestant1Id === match.winnerId 
          ? match.contestant2Id 
          : match.contestant1Id;
        
        const loser = await this.getContestantById(loserId);
        if (loser) {
          await this.updateContestant(loser.id, {
            tournamentPoints: loser.tournamentPoints + TOURNAMENT_POINTS.NINTH_SIXTEENTH
          });
        }
      }
      
      // Assign points to 17th-32nd (Round of 32 losers)
      const roundOf32 = allMatches.filter(match => match.round === 2);
      for (const match of roundOf32) {
        const loserId = match.contestant1Id === match.winnerId 
          ? match.contestant2Id 
          : match.contestant1Id;
        
        const loser = await this.getContestantById(loserId);
        if (loser) {
          await this.updateContestant(loser.id, {
            tournamentPoints: loser.tournamentPoints + TOURNAMENT_POINTS.SEVENTEENTH_THIRTYSECOND
          });
        }
      }
      
      // Assign points to 33rd-64th (Round of 64 losers)
      const roundOf64 = allMatches.filter(match => match.round === 1);
      for (const match of roundOf64) {
        const loserId = match.contestant1Id === match.winnerId 
          ? match.contestant2Id 
          : match.contestant1Id;
        
        const loser = await this.getContestantById(loserId);
        if (loser) {
          await this.updateContestant(loser.id, {
            tournamentPoints: loser.tournamentPoints + TOURNAMENT_POINTS.THIRTYTHIRD_SIXTYFOURTH
          });
        }
      }
      
      resolve();
    });
  }

  private getRandomElements<T>(array: T[], count: number): T[] {
    const shuffled = this.shuffleArray([...array]);
    return shuffled.slice(0, count);
  }

  private shuffleArray<T>(array: T[]): T[] {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }
}

export const storage = new MemStorage();
