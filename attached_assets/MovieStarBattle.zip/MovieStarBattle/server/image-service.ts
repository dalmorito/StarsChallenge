import { storage } from "./storage";
import { log } from "./vite";

// Chaves e IDs de API
const GOOGLE_API_KEY = process.env.GOOGLE_SEARCH_API_KEY;
const GOOGLE_SEARCH_ENGINE_ID = process.env.GOOGLE_SEARCH_ENGINE_ID;

// Mapeamento de imagens fixas - apenas como fallback se tudo falhar
const imageDatabase: Record<string, string[]> = {
  "default": [
    "https://source.unsplash.com/300x400/?woman,model",
    "https://source.unsplash.com/300x400/?woman,portrait",
    "https://source.unsplash.com/300x400/?woman,face"
  ]
};

/**
 * Busca imagens usando a API de Pesquisa Personalizada do Google
 * @param query A consulta de pesquisa
 * @returns Array de URLs de imagens
 */
async function searchGoogleImages(query: string): Promise<string[]> {
  if (!GOOGLE_API_KEY || !GOOGLE_SEARCH_ENGINE_ID) {
    log("Chaves de API do Google não configuradas. Usando fallback...", "image-service");
    return [];
  }

  try {
    // Usa termos mais apropriados para a busca
    const searchQuery = `${query} model portrait`;
    log(`Buscando imagens para: "${searchQuery}"`, "image-service");

    // Cria a URL da API do Google Custom Search
    const searchUrl = new URL("https://www.googleapis.com/customsearch/v1");
    searchUrl.searchParams.append("key", GOOGLE_API_KEY);
    searchUrl.searchParams.append("cx", GOOGLE_SEARCH_ENGINE_ID);
    searchUrl.searchParams.append("q", searchQuery);
    searchUrl.searchParams.append("searchType", "image");
    searchUrl.searchParams.append("num", "5"); // Solicita mais do que precisamos, caso algumas falhem
    searchUrl.searchParams.append("safe", "active"); // Ativa o filtro de segurança
    searchUrl.searchParams.append("imgSize", "medium");

    // Faz a solicitação à API
    const response = await fetch(searchUrl.toString());
    
    if (!response.ok) {
      const errorText = await response.text();
      log(`Erro na API do Google: ${response.status} - ${errorText}`, "image-service");
      return [];
    }

    const data = await response.json();
    
    // Verifica se temos resultados
    if (!data.items || data.items.length === 0) {
      log("Nenhuma imagem encontrada na pesquisa do Google", "image-service");
      return [];
    }

    // Extrai as URLs das imagens e redireciona para nosso proxy
    const imageUrls = data.items
      .map((item: any) => `/proxy-image?url=${encodeURIComponent(item.link)}`)
      .slice(0, 3);
    log(`Encontradas ${imageUrls.length} imagens via Google API`, "image-service");
    
    return imageUrls;
  } catch (error) {
    log(`Erro ao buscar imagens no Google: ${error}`, "image-service");
    return [];
  }
}

/**
 * Obtém URLs para imagens das atrizes
 * @param contestantId O ID da concorrente
 * @param name O nome da concorrente
 * @returns Um array de URLs de imagens
 */
export async function fetchContestantImages(contestantId: number, name: string): Promise<string[]> {
  try {
    // Primeiro verifica se temos imagens em cache
    const cachedImages = await storage.getImageCache(contestantId);
    if (cachedImages && cachedImages.imageUrls.length >= 3) {
      log(`Usando imagens em cache para ${name}`, "image-service");
      return cachedImages.imageUrls;
    }

    log(`Buscando imagens para ${name}`, "image-service");
    
    // Tenta buscar imagens via Google primeiro
    let imageUrls = await searchGoogleImages(name);
    
    // Se não conseguir imagens suficientes via Google, usa fallback
    if (imageUrls.length < 3) {
      log(`Não foi possível obter imagens suficientes via Google para ${name}, usando fallback...`, "image-service");
      
      // Gera URLs de fallback
      const timestamp = Date.now();
      const encodedName = encodeURIComponent(name);
      
      // Completa com imagens do Unsplash até termos 3
      while (imageUrls.length < 3) {
        const index = imageUrls.length + 1;
        imageUrls.push(`https://source.unsplash.com/300x400/?model,woman&q=${encodedName}${index}&t=${timestamp}`);
      }
    }
    
    // Armazena as imagens em cache
    await storage.createImageCache({
      contestantId,
      imageUrls,
      createdAt: new Date()
    });
    
    return imageUrls;
  } catch (error) {
    console.error(`Erro ao buscar imagens para ${name}:`, error);
    
    // Em caso de erro, retorna URLs de placeholder
    const encodedName = encodeURIComponent(name);
    return [
      `https://via.placeholder.com/300x400?text=${encodedName}+1`,
      `https://via.placeholder.com/300x400?text=${encodedName}+2`,
      `https://via.placeholder.com/300x400?text=${encodedName}+3`,
    ];
  }
}
